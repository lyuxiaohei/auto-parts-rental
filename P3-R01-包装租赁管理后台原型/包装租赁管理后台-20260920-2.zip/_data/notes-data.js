/* 原型标注数据（notes-data）——真值源：P3-R01-A03-标注数据.json，人工同步
 * 0918 拍板：页面只保留 data-note 数字角标＋本共享件引用；标注文案改动只动本文件，不再注入页面。
 * 抽屉组件：_data/notes-drawer.js。G52 全站转制（39 键＝A03 全量，2026-09-18）。 */
window.NOTES_META = {
  "codes": {
    "FP1-01": {
      "name": "项目档案",
      "desc": "项目编码、名称、状态、起止日期"
    },
    "FP1-02": {
      "name": "企业管理",
      "desc": "客户/供应商/运营方三类，联系人、开票资料"
    },
    "FP1-03": {
      "name": "包材档案",
      "desc": "围板箱/托盘/料箱，规格、单位、资产标记"
    },
    "FP1-04": {
      "name": "零部件档案",
      "desc": "物料编码、名称、供应商来源、多项目共用标记"
    },
    "FP1-05": {
      "name": "子母件 BOM",
      "desc": "母件-子件配比（A+B→C），版本管理"
    },
    "FP1-06": {
      "name": "库位档案",
      "desc": "仓库/库区/库位三级"
    },
    "FP2-01": {
      "name": "项目编码规则",
      "desc": "自动编码、规则可配置"
    },
    "FP2-02": {
      "name": "上下游绑定",
      "desc": "项目↔客户↔运营方↔供应商关系维护"
    },
    "FP2-03": {
      "name": "项目看板",
      "desc": "出入库流量、营收、盈利汇总"
    },
    "FP2-04": {
      "name": "项目明细查看明细",
      "desc": "从看板点开查看到单据"
    },
    "FP3-01": {
      "name": "采购入库单",
      "desc": "按物料基本单位入库（D-145）"
    },
    "FP3-02": {
      "name": "小组装单 ★新增",
      "desc": "A+B→C，记录运营方/时间/数量；组装后子件库存转为成品库存"
    },
    "FP3-03": {
      "name": "租赁出库单",
      "desc": "按组合件出库（一箱一件），关联项目与订单"
    },
    "FP3-04": {
      "name": "退租入库验收单",
      "desc": "回收入库，按零件核对缺损并记明细"
    },
    "FP3-05": {
      "name": "盘点单",
      "desc": "零件/组合两种方式盘点、盘损益调整"
    },
    "FP3-06": {
      "name": "库存查询",
      "desc": "零件/组合双视角实时库存，按项目/库位过滤"
    },
    "FP4-01": {
      "name": "租赁单·退回进度",
      "desc": "按单跟踪租出与已退回数量（原租出台账 2026-09-10 并入租赁单列表）"
    },
    "FP4-02": {
      "name": "库存查询·客户在租",
      "desc": "客户端(租出)按客户/项目下钻+资产轨迹（原在租台账 2026-09-10 并入库存查询）"
    },
    "FP4-03": {
      "name": "循环状态管理",
      "desc": "在租/退回/缺损/报废状态流转"
    },
    "FP4-04": {
      "name": "缺损与赔偿记录",
      "desc": "退租缺损→赔偿应收联动"
    },
    "FP5-01": {
      "name": "客户下单入口",
      "desc": "客户直接在自研系统下单（替代环通下单）"
    },
    "FP5-02": {
      "name": "订单审核",
      "desc": "我方审核客户订单"
    },
    "FP5-03": {
      "name": "订单同步",
      "desc": "订单自动同步给环通（对接方式待与环通确认）"
    },
    "FP5-04": {
      "name": "结算数据导出",
      "desc": "对环通结算数据生成与传递"
    },
    "FP6-01": {
      "name": "应收账单生成",
      "desc": "出入库数据按项目/客户自动汇总生成应收"
    },
    "FP6-02": {
      "name": "开票登记",
      "desc": "发票信息登记、与应收关联"
    },
    "FP6-03": {
      "name": "收款登记",
      "desc": "银行到账录入"
    },
    "FP6-04": {
      "name": "银行回单核销 ★补缺",
      "desc": "银行回单↔单据逐笔勾对，支持部分核销"
    },
    "FP6-05": {
      "name": "项目损益报表",
      "desc": "项目维度营收成本汇总"
    },
    "FP7-01": {
      "name": "组织与权限",
      "desc": "用户/角色/数据权限（我方/客户区分）"
    },
    "FP7-02": {
      "name": "操作日志",
      "desc": "关键操作全程记录"
    },
    "FP7-03": {
      "name": "数据字典",
      "desc": "常用选项与参数配置"
    },
    "REQ-01": {
      "name": "多项目统一管理",
      "desc": "所有项目整合进一个系统，按项目建立编码，绑定上下游关系"
    },
    "REQ-02": {
      "name": "项目维度经营分析",
      "desc": "按项目看出入库、营收、盈利情况"
    },
    "REQ-03": {
      "name": "包材租赁循环管理",
      "desc": "出库、退租、循环使用状态跟踪（围板箱/托盘/料箱）"
    },
    "REQ-04": {
      "name": "零部件级库存",
      "desc": "库存精确到零配件；配件多项目共用"
    },
    "REQ-05": {
      "name": "子母件管理",
      "desc": "一个型号含多个配件，配件采购方不同；支持组合与单独录入"
    },
    "REQ-06": {
      "name": "小组装管理节点",
      "desc": "记录 A+B→C 的组装时间与数量；库存双视角（零件/组合）"
    },
    "REQ-07": {
      "name": "客户下单入口",
      "desc": "客户直接在我方系统下单，替代在环通下单；我方审核"
    },
    "REQ-08": {
      "name": "财务开票同步",
      "desc": "出入库数据同步财务端生成应收、开票"
    },
    "REQ-09": {
      "name": "银行回单核销",
      "desc": "客户付款后单据与银行回单勾对核销"
    },
    "REQ-10": {
      "name": "环通数据对接",
      "desc": "向环通下订单、传结算数据（方式待定：接口/导出）"
    },
    "REQ-11": {
      "name": "退租缺损核对",
      "desc": "退租时按零件核对缺损（资产是我方的，需管到零件级）"
    },
    "REQ-12": {
      "name": "盘点",
      "desc": "支持零件/组合双视角盘点"
    }
  }
};

window.NOTES_DATA = {
  "首页/项目看板.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">项目经营总览</h3>",
      "title": "项目经营总览",
      "note": "跨项目经营分析：营收/在租/出入库一屏总览，数据来自各业务模块自动汇总",
      "fp": "FP2-03",
      "req": "REQ-02"
    },
    {
      "id": 2,
      "selector": "<th>本月营收(元)</th>",
      "title": "本月营收列",
      "note": "项目维度营收汇总（租赁+服务），点开可查看损益明细",
      "fp": "FP2-03",
      "req": "REQ-02"
    },
    {
      "id": 3,
      "selector": "<button class=\"btn btn-default btn-sm\" onclick=\"go('../财务协同/损益报表.html')\">损益报表</button>",
      "title": "查看损益明细",
      "note": "从看板直接进入项目损益明细",
      "fp": "FP2-04",
      "req": "REQ-02"
    },
    {
      "id": 4,
      "selector": "<div class=\"st-label\"><span>在租资产总量</span></div>",
      "title": "在租资产口径",
      "note": "较上月 +3.2% · 覆盖 4 个项目",
      "fp": "FP2-03",
      "req": "REQ-02"
    },
    {
      "id": 5,
      "selector": "<div class=\"st-label\"><span>本月租赁出库</span></div>",
      "title": "租赁出库口径",
      "note": "较上月 +8.6% · 一箱一件交付",
      "fp": "FP2-03",
      "req": "REQ-02"
    },
    {
      "id": 6,
      "selector": "<div class=\"st-label\"><span>本月收款</span></div>",
      "title": "本月收款口径",
      "note": "较上月 +12.4% · 收款核销 5 笔",
      "fp": "FP2-03",
      "req": "REQ-02"
    },
    {
      "id": 7,
      "selector": "<div class=\"st-label\"><span>应收余额</span></div>",
      "title": "应收余额口径",
      "note": "其中逾期 318,600 元",
      "fp": "FP2-03",
      "req": "REQ-02"
    }
  ],
  "项目管理/项目档案.html": [
    {
      "id": 1,
      "selector": "<button class=\"btn btn-sm\" onclick=\"openModal('createModal')\">新建项目</button>",
      "title": "新建项目（弹窗）",
      "note": "项目档案创建：编码/客户/运营方/起止日期；编码由规则自动生成",
      "fp": "FP1-01",
      "req": "REQ-01"
    },
    {
      "id": 3,
      "selector": "<button class=\"btn btn-default btn-sm\" onclick=\"openModal('bindModal')\">上下游绑定</button>",
      "title": "上下游绑定（弹窗）",
      "note": "项目↔客户↔供应商关系维护（一对多/多对多）：单项目可绑定多家供应商（勾选，含租入/采购角色）；单据按此带出候选供应商",
      "fp": "FP2-02",
      "req": "REQ-01"
    },
    {
      "id": 4,
      "selector": "<h3 class=\"modal-title\">项目上下游绑定</h3>",
      "title": "上下游绑定关系口径",
      "note": "上下游支持一对多/多对多：单项目可绑定多家供应商（勾选，含租入/采购角色），新建租入单/采购订单时按项目带出候选供应商。",
      "fp": "FP2-02",
      "req": "REQ-01"
    }
  ],
  "项目管理/项目详情.html": [
    {
      "id": 1,
      "selector": "<div class=\"card-title\" style=\"font-size:14px;margin-bottom:10px;\">上下游关系</div>",
      "title": "上下游关系（详情维护）",
      "note": "在单个项目页内维护上下游（供应商多选绑定），与项目档案共用同一份数据",
      "fp": "FP2-02",
      "req": "REQ-01"
    },
    {
      "id": 2,
      "selector": "<h3 class=\"card-title\">项目单据查询</h3>",
      "title": "项目单据查询",
      "note": "查看本项目全部出入库、租出、账单单据",
      "fp": "FP2-04",
      "req": "REQ-02"
    },
    {
      "id": 3,
      "selector": "<h3 class=\"modal-title\">项目上下游绑定</h3>",
      "title": "上下游绑定关系口径",
      "note": "上下游支持一对多/多对多：单项目可绑定多家供应商（勾选，含租入/采购角色），新建租入单/采购订单时按项目带出候选供应商。",
      "fp": "FP2-02",
      "req": "REQ-01"
    },
    {
      "id": 4,
      "selector": "<div class=\"st-label\"><span>在租数量</span></div>",
      "title": "在租数量构成",
      "note": "围板箱 3,120 / 托盘 740",
      "fp": "FP2-04",
      "req": "REQ-02"
    },
    {
      "id": 5,
      "selector": "<div class=\"st-label\"><span>本月出库</span></div>",
      "title": "本月出库构成",
      "note": "组合件 1,120 / 散件 120",
      "fp": "FP2-04",
      "req": "REQ-02"
    },
    {
      "id": 6,
      "selector": "<div class=\"st-label\"><span>本月营收</span></div>",
      "title": "营收开票口径",
      "note": "已开票 312,000 元",
      "fp": "FP2-04",
      "req": "REQ-02"
    },
    {
      "id": 7,
      "selector": "<div class=\"st-label\"><span>累计毛利</span></div>",
      "title": "毛利率口径",
      "note": "毛利率 21.8%",
      "fp": "FP2-04",
      "req": "REQ-02"
    }
  ],
  "基础数据/BOM维护.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">子项明细</h3>",
      "title": "子件明细（配比）",
      "note": "子件配比编辑；子件供应商各自不同，自动填入档案信息",
      "fp": "FP1-05",
      "req": "REQ-05"
    },
    {
      "id": 2,
      "selector": "<th>供应商（带出）</th>",
      "title": "子件供应商自动填入",
      "note": "子件采购方不同——配件分别采购、组装后组合供货",
      "fp": "FP1-05",
      "req": "REQ-05"
    },
    {
      "selector": "<th>配方来源</th>",
      "title": "BOM 维护时点",
      "note": "D-118（2026-09-14·以转写原文为准）：BOM 在物料建档后即可维护，采购前或采购后均可，按实际情况；损耗率字段已按 D-101 移除，实际损耗走库位（次品仓）区分",
      "fp": "FP1-05",
      "req": "REQ-04",
      "id": 3,
      "aud": "dev"
    }
  ],
  "基础数据/库位档案.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">库位档案</h3>",
      "title": "库位档案",
      "note": "库位两级＝库位（仓区）＋库位编码；库位列取库区命名（原料区 RA/成品区 RB/次品区 RC＋直发虚拟仓 XNC-ZF），实际损耗走次品区 RC 锁定不参与拣货",
      "fp": "FP1-06",
      "req": "REQ-04"
    },
    {
      "id": 3,
      "aud": "dev",
      "selector": "<h3 class=\"card-title\">库位档案</h3>",
      "title": "库位口径沿革",
      "note": "D-102 去库区层级（2026-09-14 第4次沟通）→2026-09-17 收口库位列取库区命名；次品区锁定不参与拣货（D-101）；直发虚拟仓 XNC-ZF（D-167）；库区层级后续做大了再加。"
    },
    {
      "id": 2,
      "selector": "<td><span class=\"lk\">XNC-ZF</span></td>",
      "title": "直发虚拟仓",
      "note": "背靠背直发账面枢纽：直发租入入库入本仓、退租归还自本仓出，不占实体库存；系统内置库位不可删改（字典 KW-05）；人工单据不可手选本仓，自动单据由系统流转"
    }
  ],
  "采购管理/采购入库列表.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">采购入库单</h3>",
      "title": "采购入库单",
      "note": "按物料基本单位入库；入库即入零件级库存",
      "fp": "FP3-01",
      "req": "REQ-04"
    },
    {
      "id": 2,
      "selector": "<button class=\"btn btn-sm\" onclick=\"go('../采购管理/采购入库录单.html')\">新增入库单</button>",
      "title": "新增入库单",
      "note": "进入录单页面（从列表页按钮打开）",
      "fp": "FP3-01",
      "req": "REQ-04"
    }
  ],
  "采购管理/采购入库录单.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">到货明细</h3>",
      "title": "到货明细（以物料基本单位入库）",
      "note": "明细按物料编码/库位记录；随附材质证明等单据",
      "fp": "FP3-01",
      "req": "REQ-04"
    },
    {
      "id": 2,
      "selector": "<button class=\"btn\">提交验收</button>",
      "title": "提交验收",
      "note": "验收通过后零件库存即时增加",
      "fp": "FP3-01",
      "req": "REQ-04"
    }
  ],
  "租赁管理/租赁出库列表.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">租赁出库单</h3>",
      "title": "租赁出库单",
      "note": "按组合件整箱交付（一箱一件），面向产线供货",
      "fp": "FP3-03",
      "req": "REQ-03"
    },
    {
      "id": 2,
      "selector": "<th>关联销售订单</th>",
      "title": "关联销售订单",
      "note": "出库与客户订单关联，退回进度自动记入租赁单列表并生成应收",
      "fp": "FP3-03",
      "req": "REQ-03"
    }
  ],
  "租赁管理/租赁出库录单.html": [
    {
      "id": 1,
      "selector": "<th>可用量校验</th>",
      "title": "可用量校验",
      "note": "出库前自动核对可用库存，避免超量发货",
      "fp": "FP3-03",
      "req": "REQ-03"
    },
    {
      "id": 2,
      "selector": "<button class=\"btn\">提交出库</button>",
      "title": "提交出库",
      "note": "出库后成品库存自动减少、租赁单列表退回进度自动登记（原租出台账并入）、应收按项目自动汇总",
      "fp": "FP3-03",
      "req": "REQ-03"
    }
  ],
  "仓储作业/盘点列表.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">盘点单</h3>",
      "title": "盘点单（两种方式）",
      "note": "可按零件或组合两种方式盘点",
      "fp": "FP3-05",
      "req": "REQ-12"
    }
  ],
  "仓储作业/盘点录入.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">盘点明细</h3>",
      "title": "盘点明细",
      "note": "账面数量自动填入，实盘手工录入，差异自动算出",
      "fp": "FP3-05",
      "req": "REQ-12"
    },
    {
      "id": 2,
      "selector": "<h3 class=\"card-title\">损益处理</h3>",
      "title": "损益处理",
      "note": "盘损益调整入库存账",
      "fp": "FP3-05",
      "req": "REQ-12"
    },
    {
      "selector": "<th class=\"sticky-op\">操作</th>",
      "title": "盘点行内生成其他出入库",
      "note": "每物料行内按差异方向生成其他入库（盘盈）/其他出库（盘亏），跳创建页自动带物料；类型域含「破损/自然损耗」（保留既有赔偿核销等值）",
      "fp": "FP5-02",
      "req": "REQ-06",
      "id": 3
    },
    {
      "selector": "<th>差异处理</th>",
      "title": "盘点行内生成沿革",
      "note": "D-110（2026-09-14）落地：行内按差异方向生成其他出入库；类型域后补「破损/自然损耗」值（保留赔偿核销）。",
      "fp": "FP5-02",
      "req": "REQ-06",
      "id": 4,
      "aud": "dev"
    }
  ],
  "仓储作业/库存查询.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">库存状态查询</h3>",
      "title": "库存双视角查询",
      "note": "物料视角 / BOM 视角切换——本次新增能力",
      "fp": "FP3-06",
      "req": "REQ-06"
    },
    {
      "id": 2,
      "selector": "<div class=\"st-label\"><span>在库</span></div>",
      "title": "库存五态口径",
      "note": "在库＝仓库内可用（其中组装占用 3,920 件，按 BOM 结果导向扣组件，不管理组装过程）。\n五态：在库 / 在客户（租出）/ 客户转租出（客户的客户）/ 退租在途 / 租入在库。\n在途＝应入库未入库（退租待入库 / 采购到货待入库 / 租入到货待入库）；租入＝租入在库未转租，转租后计入客户态（来源标记区分）。",
      "fp": "FP3-06",
      "req": "REQ-06"
    },
    {
      "id": 3,
      "selector": "<div class=\"st-label\"><span>在客户</span></div>",
      "title": "客户虚拟仓与在租明细",
      "note": "客户虚拟仓＝在客户处的租赁资产按客户归集（on-hire）；客户转租为其子状态。\n客户在租明细＝行内「客户在租」按客户/项目下钻；租出与退回进度在租赁单列表「退回进度」列跟踪。\n对应在租租赁单 40 张。",
      "fp": "FP4-02",
      "req": "REQ-03"
    },
    {
      "id": 7,
      "aud": "dev",
      "selector": "<div class=\"st-label\"><span>在客户</span></div>",
      "title": "客户虚拟仓口径沿革",
      "note": "客户转租为子状态（2026-09-08 会议 T1 方向）；客户在租明细原在租台账（2026-09-10 并入）。"
    },
    {
      "id": 4,
      "selector": "<div class=\"st-label\"><span>客户转租出</span></div>",
      "title": "客户转租（客户的客户）",
      "note": "转租定义：物料/BOM 已租给客户 A，A 再租给客户 B（终端用户）——记为「客户转租出」，不做所有权变更。\n承载＝转移出库单——库存查询行内「转移出库」跳录单页（带出物料与在租客户），审核生效后状态转「客户转租出」；单据「终止转移」后回「在客户（租出）」。\n结算：项目档案「转租结算方式」定默认（按租出结算/按终端结算），转移单可按单覆盖。",
      "fp": "FP3-06",
      "req": "REQ-06"
    },
    {
      "id": 8,
      "aud": "dev",
      "selector": "<div class=\"st-label\"><span>客户转租出</span></div>",
      "title": "客户转租承载沿革",
      "note": "G37·D-146（2026-09-15）转移出库单承载（原转租登记/转租还回弹窗退场）；结算两模式 D-132。"
    },
    {
      "id": 5,
      "selector": "<div class=\"st-label\"><span>退租在途</span></div>",
      "title": "退租在途（无独立审核）",
      "note": "客户已通知退租 500 件 · 退租入库待确认 7 单。\n退租只做两件事——在途（客户通知）→ 退租入库（改库存），无独立审核环节。",
      "fp": "FP3-06",
      "req": "REQ-06"
    },
    {
      "id": 9,
      "aud": "dev",
      "selector": "<div class=\"st-label\"><span>退租在途</span></div>",
      "title": "退租在途沿革",
      "note": "退租申请模块已移除（2026-09-08 会议），退租无独立审核环节。"
    },
    {
      "id": 6,
      "selector": "<div class=\"st-label\"><span>租入在库</span></div>",
      "title": "租入在库",
      "note": "关联租入单 2 张 · 按月生成租金应付（环通）；租入在库未转租计入本态，转租后计入客户态（来源标记区分）。",
      "fp": "FP3-06",
      "req": "REQ-06"
    }
  ],
  "财务协同/应收账单.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">应收账单</h3>",
      "title": "应收账单自动生成",
      "note": "出入库数据按项目/客户自动生成应收——告别手工对账",
      "fp": "FP6-01",
      "req": "REQ-08"
    },
    {
      "id": 2,
      "selector": "<button class=\"btn btn-sm\" onclick=\"openModal('createModal')\">手动生成账单</button>",
      "title": "手动生成账单",
      "note": "以自动生成为主，特殊情况可手工补开账单",
      "fp": "FP6-01",
      "req": "REQ-08"
    }
  ],
  "财务协同/开票登记.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">开票登记</h3>",
      "title": "开票登记",
      "note": "发票信息登记并与应收账单关联",
      "fp": "FP6-02",
      "req": "REQ-08"
    }
  ],
  "财务协同/收款登记.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">收款登记</h3>",
      "title": "收款登记",
      "note": "银行到账后录入收款记录",
      "fp": "FP6-03",
      "req": "REQ-09"
    },
    {
      "id": 2,
      "selector": "<th>银行回单</th>",
      "title": "银行回单",
      "note": "银行回单是核销勾对的凭据",
      "fp": "FP6-03",
      "req": "REQ-09"
    }
  ],
  "财务协同/银行回单核销.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">① 银行回单</h3>",
      "title": "银行回单（左栏）",
      "note": "★ 目前靠手工核销，系统上线后自动完成：银行回单与单据左右对照勾对",
      "fp": "FP6-04",
      "req": "REQ-09"
    },
    {
      "id": 2,
      "selector": "<button class=\"btn btn-default btn-sm\" onclick=\"autoMatch()\">自动匹配建议</button>",
      "title": "自动匹配建议",
      "note": "按付款户名/金额智能推荐勾对，支持部分核销",
      "fp": "FP6-04",
      "req": "REQ-09"
    },
    {
      "id": 3,
      "selector": "<button class=\"btn btn-sm\">生成核销记录</button>",
      "title": "生成核销记录",
      "note": "一笔收款可以分多次核销多张单据",
      "fp": "FP6-04",
      "req": "REQ-09"
    },
    {
      "id": 4,
      "selector": "<h3 class=\"card-title\">② 待核销单据</h3>",
      "title": "核销金额口径",
      "note": "单据金额取自应收账单 / 丢损赔偿单；勾选两侧后点击「生成核销记录」，系统按回单未核销金额与单据未核销金额取小核销。",
      "fp": "FP6-04",
      "req": "REQ-09"
    }
  ],
  "财务协同/损益报表.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">项目损益</h3>",
      "title": "项目损益表",
      "note": "项目维度收入/成本/损益汇总（租赁+组装服务+赔偿 vs 摊销+成本）",
      "fp": "FP6-05",
      "req": "REQ-02"
    },
    {
      "id": 2,
      "aud": "dev",
      "selector": "<div class=\"pager\">",
      "title": "演示链数据对齐",
      "note": "对齐说明（演示链数据）：PRJ-2601 收入合计 486,200.00 ＝ 应收账单 AR-2026-08-PRJ2601（已开票 186,200 · 银行回单部分核销 286,500，见开票登记 / 银行回单核销）；PRJ-2604 为 L4 混合链演示项目——租入大箱租金应付 AP-20260903-010（12,000.00 / 月）与自购隔板采购摊销计入成本合计，9 月销售费应收 AR-2026-09-PRJ2604-S1（1,280.00）见应收账单；当前成本大于收入、毛利为负（项目状态：已暂停）。",
      "fp": "FP6-05",
      "req": "REQ-02"
    },
    {
      "id": 3,
      "selector": "<div class=\"st-label\"><span>本月营业收入</span></div>",
      "title": "营收构成",
      "note": "租赁 990,700 / 组装 130,000 / 赔偿 18,200",
      "fp": "FP6-05",
      "req": "REQ-02"
    },
    {
      "id": 4,
      "selector": "<div class=\"st-label\"><span>本月营业成本</span></div>",
      "title": "成本构成",
      "note": "器具摊销 505,200 / 仓储 154,300",
      "fp": "FP6-05",
      "req": "REQ-02"
    },
    {
      "id": 5,
      "selector": "<div class=\"st-label\"><span>本月毛利</span></div>",
      "title": "毛利率",
      "note": "毛利率 42.1%",
      "fp": "FP6-05",
      "req": "REQ-02"
    },
    {
      "id": 6,
      "selector": "<div class=\"st-label\"><span>亏损项目</span></div>",
      "title": "亏损项目口径",
      "note": "PRJ-2604 -18,600 元（已暂停）",
      "fp": "FP6-05",
      "req": "REQ-02"
    }
  ],
  "系统管理/用户权限.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">用户与权限</h3>",
      "title": "用户与权限",
      "note": "我方/客户/运营方三类账号体系——客户端登录即在此配置",
      "fp": "FP7-01",
      "req": "REQ-01"
    },
    {
      "id": 2,
      "selector": "<th>数据权限范围</th>",
      "title": "数据权限范围",
      "note": "按项目与所属方划分权限，客户只能看到自己的单据",
      "fp": "FP7-01"
    },
    {
      "id": 3,
      "aud": "dev",
      "selector": "<h3 class=\"modal-title\">角色管理</h3>",
      "title": "可审单据同源同步",
      "note": "与角色管理页·权限配置「可审单据」同源同步（双层同步 · G13）；正式版按所选角色加载勾选态。",
      "fp": "FP7-01",
      "req": "REQ-01"
    }
  ],
  "系统管理/操作日志.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">操作日志</h3>",
      "title": "操作日志",
      "note": "关键操作全程记录，组装、核销等敏感操作可查",
      "fp": "FP7-02"
    }
  ],
  "系统管理/数据字典.html": [
    {
      "id": 1,
      "selector": "<div class=\"card-title\" style=\"font-size:14px;margin:6px 6px 10px;\">字典分类</div>",
      "title": "数据字典",
      "note": "常用选项与参数集中设置",
      "fp": "FP7-03"
    },
    {
      "id": 2,
      "selector": "<h3 class=\"card-title\">计费方式</h3>",
      "title": "计费方式",
      "note": "租金计费规则：按次 / 按时间周期（年·月·日，默认月）；物料档案租价与租入单明细「计费方式」列均以本字典为值源。",
      "req": "REQ-03"
    }
  ],
  "基础数据/产品档案.html": [
    {
      "id": 1,
      "selector": "<div class=\"tax-sec-title\">供应商税率",
      "title": "税率口径与档案合并",
      "note": "同一物料可按供应商维护不同税率（默认 13%；运费/杂费后续可能 6%/9%）；单据明细税率默认带出、可手动覆盖。\n税率在新建物料弹窗内按供应商维护（行编辑器）；本页不再单列维护表。",
      "fp": "",
      "req": ""
    },
    {
      "id": 2,
      "aud": "dev",
      "selector": "<div class=\"tax-sec-title\">供应商税率",
      "title": "物料档案合并沿革",
      "note": "物料档案＝器具档案＋零部件档案合并（2026-09-08 会议 N4）。"
    }
  ],
  "仓储作业/库存调拨列表.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">库存调拨单</h3>",
      "title": "调拨范围与生效口径",
      "note": "第一期仅支持同仓群内的库位调拨，不做调拨在途管理；调拨审核通过后即时完成库存转移。",
      "fp": "FP3-06",
      "req": "REQ-06"
    }
  ],
  "财务协同/应付账单.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">应付账单</h3>",
      "title": "应付账单生成方式",
      "note": "应付账单可由采购入库单审核后自动生成（第一期支持手动创建）；租入业务（环通）按周期生成应付账单。",
      "fp": "FP4-02",
      "req": "REQ-03"
    }
  ],
  "项目管理/弹窗/上下游绑定.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"modal-title\">项目上下游绑定</h3>",
      "title": "上下游绑定关系口径",
      "note": "上下游支持一对多/多对多：单项目可绑定多家供应商（勾选，含租入/采购角色），新建租入单/采购订单时按项目带出候选供应商。",
      "fp": "FP2-02",
      "req": "REQ-01"
    }
  ],
  "系统管理/角色管理.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"modal-title\"><span id=\"rolePermTitle\">权限配置 · 系统管理员</span></h3>",
      "title": "可审单据与审核人匹配",
      "note": "勾选该角色可审核的单据类型；各审核弹窗「审核人（按角色匹配）」据此匹配。",
      "fp": "FP7-01",
      "req": "REQ-01"
    }
  ],
  "系统管理/弹窗/权限配置.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"modal-title\"><span id=\"rolePermTitle\">权限配置 · 系统管理员</span></h3>",
      "title": "可审单据与审核人匹配",
      "note": "勾选该角色可审核的单据类型；各审核弹窗「审核人（按角色匹配）」据此匹配。",
      "fp": "FP7-01",
      "req": "REQ-01"
    }
  ],
  "租赁管理/弹窗/租赁单新建.html": [
    {
      "id": 1,
      "aud": "dev",
      "selector": "<span class=\"form-label\">押金(元)</span>",
      "title": "押金=设计预留字段",
      "note": "押金为设计预留字段——两次会议均未涉及，收退与计价商务口径待客户确认（F01 财务通道注记同步）",
      "fp": "FP4-02",
      "req": "REQ-03"
    },
    {
      "selector": "<span class=\"req\">*</span>计费方式",
      "title": "免费借用形态",
      "note": "D-115（2026-09-14 形态认可）：免费借用＝租赁/销售单价填 0 不结算，不加专门结构；财务合规口径严工问财务待复",
      "fp": "FP2-01",
      "req": "REQ-01",
      "id": 2,
      "aud": "dev"
    }
  ],
  "我的待办.html": [
    {
      "id": 1,
      "selector": "<div class=\"st-label\"><span>我的待办</span></div>",
      "title": "待办总量口径",
      "note": "覆盖 20 类单据 · 点击“去审核”直达审核弹窗"
    },
    {
      "id": 2,
      "selector": "<div class=\"st-label\"><span>待审核</span></div>",
      "title": "待审核构成",
      "note": "订单/出入库/租赁/盘点等"
    },
    {
      "id": 3,
      "selector": "<div class=\"st-label\"><span>待验收</span></div>",
      "title": "待验收含义",
      "note": "采购入库到货验收"
    },
    {
      "id": 4,
      "selector": "<div class=\"st-label\"><span>待确认</span></div>",
      "title": "待确认含义",
      "note": "付款 / 收款登记确认"
    },
    {
      "id": 5,
      "selector": "<div class=\"st-label\"><span>待入库</span></div>",
      "title": "待入库含义",
      "note": "租入入库 · 确认后计租入资产库存"
    }
  ],
  "mobile/审批详情.html": [
    {
      "id": 1,
      "aud": "dev",
      "selector": "<div class=\"m-sec-title\">单据明细</div>",
      "title": "明细=静态演示数据",
      "note": "单据明细为静态示例（演示数据），演示移动端审批详情形态。"
    },
    {
      "id": 2,
      "selector": "<div class=\"m-sec-title\">单据摘要</div>",
      "title": "审批动作口径",
      "note": "通过后单据进入下一环节并通知提交人；驳回后退回提交人修改后重新提交。"
    }
  ],
  "基础数据/客商管理.html": [
    {
      "id": 1,
      "selector": "<button class=\"btn btn-sm\" onclick=\"openModal('createModal')\">",
      "title": "新建客商",
      "note": "客户/供应商两类主体；开票资料、收货信息在新建/编辑页随基础信息一并维护，详情页分三段展示",
      "fp": "FP1-02",
      "req": "REQ-01"
    }
  ],
  "租入管理/租入入库列表.html": [
    {
      "selector": "<div class=\"form-label\" style=\"padding-top:4px;\">类型：</div>",
      "title": "直发自动生成租赁出库",
      "note": "租入单类型=直发时，入库确认后系统自动生成租赁出库单（自动带物料·免重复填单·租赁出库列表可查自动生成单）；计费口径不受影响。",
      "fp": "FP2-01",
      "req": "REQ-02",
      "id": 1
    },
    {
      "selector": "<div class=\"form-label\" style=\"padding-top:4px;\">类型：</div>",
      "title": "直发触发口径沿革",
      "note": "D-167 类型驱动（09-18 袁工口径）替代 D-105 入库勾选触发；计费口径不受影响（D-122）。",
      "fp": "FP2-01",
      "req": "REQ-02",
      "id": 2,
      "aud": "dev"
    }
  ],
  "租入管理/弹窗/租入单新建.html": [
    {
      "id": 1,
      "selector": "<th>计费方式</th>",
      "title": "租入计费口径",
      "note": "计费＝月租金 + 按套数单价（不设日租金）；应付生成方式取决于租入单模式（静态租入 / 背靠背）。",
      "fp": "FP4-02",
      "req": "REQ-03"
    }
  ],
  "租入管理/弹窗/归还出库新建.html": [
    {
      "id": 1,
      "selector": "<tbody id=\"riItemsBody\">",
      "title": "分批归还口径",
      "note": "支持分批归还：多张归还单可对应同一租入单；逐物料填写本次归还数量，「已归还」为该租入单历史累计。\n归还明细行随所选租入单的明细行数联动展示。"
    }
  ],
  "租入管理/租入单列表.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">租入单</h3>",
      "title": "租入单类型",
      "note": "类型=直发（供应商直发客户）/自发（先入我方库再发）；直发审核通过后系统自动生成租入入库与租赁出库"
    },
    {
      "id": 2,
      "aud": "dev",
      "selector": "<h3 class=\"card-title\">租入单</h3>",
      "title": "类型口径沿革",
      "note": "09-18 袁工口径定类型加在租入单（D-167）；命名 09-19 道远复核定稿=直发/自发（不带单字）。"
    }
  ],
  "租入管理/租入入库详情.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\" id=\"dtTitle\">租入入库单详情</h3>",
      "title": "直发链自动化",
      "note": "直发链自动化：直发租入单→自动生成本单（入直发虚拟仓·不占实体库存）→自动生成租赁出库并关联"
    },
    {
      "id": 2,
      "aud": "dev",
      "selector": "<h3 class=\"card-title\" id=\"dtTitle\">租入入库单详情</h3>",
      "title": "直发链口径沿革",
      "note": "第4次「立即转租」口径 09-18 升级为类型驱动（D-167）。"
    }
  ],
  "租赁管理/退租入库详情.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\" id=\"dtTitle\">退租入库单详情</h3>",
      "title": "背靠背退租闭环",
      "note": "背靠背退租闭环：客户退租人工录本单→系统识别原租入单为直发类型→库位自动带出直发虚拟仓→自动生成归还出库（GHCK）；客户报数增减亦经出入库单人工调整虚拟仓账面（#15）"
    }
  ],
  "采购管理/采购退货单列表.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">采购退货单</h3>",
      "title": "采购退货单",
      "note": "双退货单之一：收货拒收（未入库直接退·不产生库存流水）／入库后退货（已入库再退·凭退货单自身冲减，不修改原入库单）。审核后可登记应付退款（对供应商）。",
      "fp": "",
      "req": ""
    },
    {
      "id": 2,
      "selector": "<button class=\"btn btn-sm\" onclick=\"openModal('createModal')\">新建退货单</button>",
      "title": "新建退货单",
      "note": "选择关联原单（采购入库单）自动带出物料行与可退上限；退货类型两值（THC 字典）。",
      "fp": "",
      "req": ""
    }
  ],
  "销售管理/销售退货单列表.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">销售退货单</h3>",
      "title": "销售退货单（方案 B）",
      "note": "客户退货统一单据：收货拒收（客户未收货直接退回）／入库后退货（客户收货使用后退货回仓）。审核后可登记应收退款（对客户）。",
      "fp": "",
      "req": ""
    },
    {
      "id": 2,
      "selector": "<button class=\"btn btn-sm\" onclick=\"openModal('createModal')\">新建退货单</button>",
      "title": "新建退货单",
      "note": "选择关联销售出库单自动带出物料行与可退上限。",
      "fp": "",
      "req": ""
    }
  ],
  "财务协同/退款登记.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\">退款登记</h3>",
      "title": "退款登记（一页双向）",
      "note": "退款为独立可查可审单据。方向映射固定：采购退货→应付退款（对供应商·收款）；销售退货→应收退款（对客户·付款）。",
      "fp": "",
      "req": ""
    },
    {
      "id": 3,
      "aud": "dev",
      "selector": "<h3 class=\"card-title\">退款登记</h3>",
      "title": "退款登记沿革",
      "note": "G32-T1 方案 B·D-123 从核销散记升级为独立单据；「供应商应收」既有行（AR-20260904-015·赔付用途）不动。"
    },
    {
      "id": 2,
      "selector": "<button class=\"btn btn-sm\" onclick=\"openModal('createModal')\">新建退款单</button>",
      "title": "新建退款单",
      "note": "退款类型（TKL 字典）决定往来单位方向与资金方向；关联退货单带出可退金额。",
      "fp": "",
      "req": ""
    }
  ],
  "租赁管理/转移出库列表.html": [
    {
      "id": 1,
      "selector": "<span class=\"lk\">ZY-20260914-002</span>",
      "title": "转移出库单",
      "note": "直接客户→终端客户的器具转移，一步式·不勾稽原租赁单。审核通过后转移生效，库存状态转「客户转租出」；「终止转移」后回「在客户（租出）」。结算方式默认取项目档案「转租结算方式」可按单覆盖。",
      "fp": "FP3-06",
      "req": "REQ-06"
    },
    {
      "id": 2,
      "aud": "dev",
      "selector": "<span class=\"lk\">ZY-20260914-002</span>",
      "title": "转移出库沿革",
      "note": "D-146 落地（09-16 拍板加审·审核页承载）；转租登记/转租还回弹窗退场由本单承载；不勾稽 D-106；结算 D-132。"
    }
  ],
  "租赁管理/转移出库新建.html": [
    {
      "id": 1,
      "selector": "<div class=\"form-label\" style=\"padding-top:6px;\"><span class=\"req\">*</span>结算方式：</div>",
      "title": "结算方式两值",
      "note": "默认取项目档案「转租结算方式」，可单据级覆盖。按租出结算＝租金仍向直接客户计收，转移单不进财务链路；按终端结算＝生效后后续账单主体切终端客户，历史账单不回改。终端客户可选客商档案或手工录入（不强制建档）。",
      "fp": "FP4-02",
      "req": "REQ-03"
    },
    {
      "id": 2,
      "aud": "dev",
      "selector": "<div class=\"form-label\" style=\"padding-top:6px;\"><span class=\"req\">*</span>结算方式：</div>",
      "title": "结算口径沿革",
      "note": "结算两模式 D-132；终端客户不强制建档 D-108。"
    }
  ],
  "租赁管理/转移出库单详情.html": [
    {
      "id": 1,
      "selector": "<h3 class=\"card-title\" id=\"dtTitle\">转移出库单详情</h3>",
      "title": "转移出库单",
      "note": "转出方（直接客户）→ 本单 → 接收方（终端客户）三段链。财务口径：按租出结算不生成应收账单；按终端结算后续账单主体切换为终端客户（历史账单不回改）。",
      "fp": "FP3-06",
      "req": "REQ-06"
    }
  ]
};