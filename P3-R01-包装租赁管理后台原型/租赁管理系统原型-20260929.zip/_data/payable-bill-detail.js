/* ============================================================================
 * 应付账单详情弹窗 · 数据渲染（依赖 demo-data.js 的 payableBills）
 * ----------------------------------------------------------------------------
 * 用法：
 *   <script src="../_data/demo-data.js"></script>
 *   <script src="../_data/payable-bill-detail.js"></script>
 *   列表页：openPayableBillDetail('AP-20260903-009')          （base 默认 '../'）
 *   弹窗模板预览（弹窗/ 目录）：openPayableBillDetail('AP-xxx', '../../')
 *
 * 要求页面弹窗骨架带两个挂载点：#detailTitle（标题）、#detailBody（正文容器），
 * 且已定义 go(url) / openModal(id)。
 * ========================================================================== */
(function () {
  var STATUS_CLS = { '未付款': 'tag-red', '部分付款': 'tag-orange', '已付款': 'tag-green' };

  function fmt(n) {
    return Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function lk(text, url, base) {
    return url ? '<span class="lk" onclick="go(\'' + base + url + '\')">' + text + '</span>' : text;
  }
  function drow(label, valHtml, full) {
    return '<div class="drow"' + (full ? ' style="grid-column:1/-1;"' : '') +
      '><div class="dlabel">' + label + '</div><div class="dval">' + valHtml + '</div></div>';
  }

  /* 四段式详情 HTML：单据信息 / 费用明细 / 关联单据互溯链 / 流转时间线 */
  window.renderPayableBillDetailHTML = function (b, base) {
    base = base || '../';
    var h = '';

    h += '<div class="dt-sec">单据信息</div><div class="dgrid c3">';
    h += drow('应付账单号', b.billNo);
    h += drow('状态', '<span class="tag ' + (STATUS_CLS[b.status] || 'tag-gray') + '">' + b.status + '</span>');
    h += drow('供应商', b.supplier, true);
    h += drow('账单类型', b.billType);
    h += drow('所属项目', b.project);
    h += drow('账期', b.period);
    /* G42 T7b：账单日期/到期日/备注（详情-新建字段匹配补差） */
    h += drow('账单日期', (b.row && b.row.fields && b.row.fields.date) || '—');
    h += drow('到期日', (function () { var c = b.row && b.row.cells; return (c && c[10] && /^\d{4}-\d{2}-\d{2}$/.test(c[10])) ? c[10] : '—'; })());
    h += drow('备注', '—');
    (b.refs || []).forEach(function (r) {
      h += drow(r.label, r.no === '—' ? '—' : lk(r.no, r.url, base));
    });
    h += drow('账单金额', fmt(b.amount) + ' 元');
    h += drow('已付款', fmt(b.paid) + ' 元');
    h += drow('生成方式', b.genMode);
    h += '</div>';

    h += '<div class="dt-sec">费用明细</div>';
    if (b.segCols) {
      /* G39 期段化明细（D-148）：起租日期|止租日期|天数|日单价|小计（按持有量×天数） */
      h += '<div class="table-wrap"><table><thead><tr>' +
        b.segCols.map(function (c) { return '<th>' + c + '</th>'; }).join('') + '</tr></thead><tbody>';
      b.fees.forEach(function (f) {
        h += '<tr>' + (f.cells || []).map(function (c, i) {
          return '<td' + (i >= b.segCols.length - 2 ? ' class="td-num"' : '') + '>' + c + '</td>';
        }).join('') + '</tr>';
      });
      h += '</tbody></table></div>';
    } else {
      h += '<div class="table-wrap"><table><thead><tr><th>来源单据</th><th>费用说明</th><th class="td-num">金额(元)</th></tr></thead><tbody>';
      b.fees.forEach(function (f) {
        h += '<tr><td>' + (f.url ? lk(f.src, f.url, base) : f.src) + '</td><td>' + f.desc +
          '</td><td class="td-num">' + fmt(f.amount) + '</td></tr>';
      });
      h += '</tbody></table></div>';
    }

    h += '<div class="dt-sec">关联单据</div><div class="chain">';
    b.chain.forEach(function (n, i) {
      if (i > 0) h += '<span class="link-arrow">→</span>';
      h += '<div class="node"' + (n.self ? ' style="border-color:#1677ff;background:#e6f4ff;"' : '') +
        '><div class="n-role">' + n.role + '</div><div class="n-name">' +
        (n.url ? lk(n.name, n.url, base) : n.name) + '</div></div>';
    });
    h += '</div>';

    h += '<div class="dt-sec">流转时间线</div><div class="tl">';
    b.timeline.forEach(function (t) {
      h += '<div class="tl-i' + (t.off ? ' off' : '') + '"><span class="tl-t">' + t.t + '</span>' +
        t.text + (t.who ? '<span class="tl-who">' + t.who + '</span>' : '') + '</div>';
    });
    h += '</div>';
    return h;
  };

  window.openPayableBillDetail = function (billNo, base) {
    var b = window.DEMO_DATA && window.DEMO_DATA.payableBills ? window.DEMO_DATA.payableBills[billNo] : null;
    if (!b) { console.warn('[demo-data] 应付账单无数据: ' + billNo); return; }
    document.getElementById('detailTitle').textContent = '应付账单详情 · ' + billNo;
    document.getElementById('detailBody').innerHTML = window.renderPayableBillDetailHTML(b, base);
    openModal('detailModal');
  };
})();
